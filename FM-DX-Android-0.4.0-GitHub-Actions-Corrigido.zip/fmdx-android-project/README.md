# FM-DX Android — versão 0.3.0 (projeto-fonte)

Aplicativo Android de acesso ao FM-DX Webserver, acompanhado de um serviço de diretório para que proprietários possam publicar servidores independentes ou manter o acesso privado por convite.

## Componentes

- `android/`: aplicativo Android nativo em Kotlin. A interface combina a identidade original FM-DX com navegação e telas adaptadas para celular.
- `directory-service/`: API Node.js para cadastro autenticado e listagem pública de servidores.
- `fm-dx-webserver/`: código do FM-DX Webserver incluído no ZIP original, preservado junto da modificação Exclusive Tuner.

## O que o app faz nesta versão

- Abre servidores FM-DX existentes pelo endereço HTTP/HTTPS.
- Lista servidores públicos consultando o diretório configurado.
- Filtra a lista pública por nome, cidade, país e descrição.
- Salva e remove servidores favoritos/endereço privado no próprio aparelho.
- Permite configurar o endereço HTTPS do diretório dentro do aplicativo.
- Usa WebView com JavaScript, armazenamento DOM e suporte ao player web do FM-DX.
- Mantém a navegação de voltar dentro do servidor aberto antes de retornar à tela inicial.
- Libera o WebView ao sair da tela ou encerrar a Activity, reduzindo consumo e retenção de recursos.
- Valida URLs HTTP/HTTPS e rejeita endereços com credenciais embutidas.

## O que ainda não faz

- Não transforma o celular em receptor FM nem executa o servidor de hardware no Android.
- Não instala nem configura automaticamente o receptor USB/serial no computador do proprietário.
- Não possui cadastro de conta, painel web de administração, moderação ou verificação automática de disponibilidade dos servidores.
- O diretório não retransmite áudio: ele apenas cataloga endereços. Cada servidor transmite diretamente aos ouvintes.
- Não foi possível gerar ou testar um APK neste ambiente porque não há Android SDK/Gradle instalado. A compilação e os testes em aparelho real ainda são necessários.

## Requisitos do servidor FM-DX

O proprietário mantém o FM-DX Webserver em um computador Windows/Linux/macOS e um receptor compatível. Consulte `fm-dx-webserver/README.md` e os guias oficiais de instalação do projeto. O Android é cliente para administração/acesso e audição; o receptor físico permanece ligado ao computador do servidor.

## Configurar o diretório (Node.js)

1. Instale Node.js LTS no computador/servidor.
2. Abra um terminal nesta pasta `directory-service/` e execute:

   ```bash
   npm install
   ```

3. Defina um token forte e privado antes de iniciar o serviço.

   **Windows PowerShell:**
   ```powershell
   $env:DIRECTORY_ADMIN_TOKEN = 'COLOQUE_UM_TOKEN_LONGO_E_ALEATORIO'
   $env:PORT = '8787'
   npm start
   ```

   **Linux/macOS:**
   ```bash
   export DIRECTORY_ADMIN_TOKEN='COLOQUE_UM_TOKEN_LONGO_E_ALEATORIO'
   export PORT=8787
   npm start
   ```

4. Publique o serviço atrás de HTTPS (proxy reverso com certificado TLS). Não exponha o endpoint administrativo sem HTTPS e não compartilhe o token.
5. Teste `https://SEU-DOMINIO/health`. A resposta esperada contém `ok: true`.
6. No FM-DX Android, abra **Configurações do diretório** e informe a URL base, por exemplo `https://SEU-DOMINIO/api`.

O arquivo `servers.json` é o armazenamento simples desta versão. Configure volume/disco persistente e cópias de segurança no host de produção.

## Cadastrar um servidor no diretório

O cadastro é feito por uma requisição autenticada. Há um script PowerShell em `directory-service/register-server.ps1`:

```powershell
.\register-server.ps1 `
  -DirectoryApi 'https://SEU-DOMINIO/api' `
  -ServerName 'Minha estação FM-DX' `
  -ServerUrl 'https://RADIO-SEU-DOMINIO' `
  -AdminToken 'SEU_TOKEN' `
  -City 'Jauru' `
  -Country 'Brasil' `
  -Description 'Receptor FM-DX' `
  -Visibility public
```

Use `-Visibility private` para não incluir o endereço na listagem pública. Para compartilhar um servidor privado, envie o endereço diretamente às pessoas autorizadas. O aplicativo salva esse endereço localmente em **Meus servidores**.

### Endpoints

- `GET /health` — estado do serviço.
- `GET /api/servers` — lista somente servidores públicos.
- `GET /api/servers/:id` — detalhes de um servidor público.
- `POST /api/servers` — cria/atualiza cadastro; exige `Authorization: Bearer TOKEN`.
- `DELETE /api/servers/:id` — remove cadastro; exige o mesmo token.

## Compilar o APK no Android Studio

1. Instale Android Studio estável e os componentes Android SDK para API 35.
2. Abra a pasta `android/` (não a pasta raiz inteira) no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração normalmente será criado em `android/app/build/outputs/apk/debug/app-debug.apk`.
6. Instale primeiro em aparelho de teste e valide áudio, WebSocket, navegação e servidores HTTP/HTTPS.

O pacote entregue é o código-fonte. A compilação do APK ainda precisa ser feita no Android Studio, pois este ambiente não possui Android SDK/Gradle configurados.

Configuração atual: `minSdk 26` (Android 8.0 ou superior), `targetSdk 35`, `versionCode 3`, `versionName 0.3.0`.

## Segurança e operação

- Prefira HTTPS para servidores e diretório publicados na internet.
- Use autenticação do próprio FM-DX Webserver quando houver acesso remoto de administração.
- Não publique URLs privadas nem tokens no diretório público.
- O diretório não faz proxy de áudio e não deve receber credenciais dos servidores FM-DX.
- O campo de endereço no app aceita HTTP para redes locais; conexões HTTP públicas não oferecem criptografia.
- Antes de uma publicação ampla, adicionar verificação de disponibilidade, moderação, política de privacidade, proteção contra abuso e testes de carga.

## Licenças

O código FM-DX Webserver incluído mantém seus arquivos e avisos de licença originais. Consulte `fm-dx-webserver/LICENSE` e as licenças das dependências antes de redistribuir. Verifique também as obrigações GPLv3 aplicáveis a versões modificadas.

## Compilar APK pelo GitHub Actions

O arquivo `.github/workflows/android-apk.yml` compila o APK de depuração na nuvem. Envie o conteúdo deste projeto para a raiz do repositório GitHub, abra **Actions**, selecione **Compilar APK Android** e use **Run workflow**. Ao concluir com sucesso, baixe o artefato `FM-DX-Android-0.4.0-debug`; dentro dele estará `app-debug.apk`. A compilação usa Java 17 e Gradle 8.9. Consulte `COMPILAR-NO-GITHUB.txt` para o passo a passo.
