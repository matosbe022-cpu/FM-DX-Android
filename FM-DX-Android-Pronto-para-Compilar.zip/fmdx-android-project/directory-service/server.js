const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
app.use(express.json({ limit: '16kb' }));
const PORT = Number(process.env.PORT || 8787);
const TOKEN = process.env.DIRECTORY_ADMIN_TOKEN || '';
const DB = process.env.DIRECTORY_DB || path.join(__dirname, 'servers.json');
function read() { try { return JSON.parse(fs.readFileSync(DB, 'utf8')); } catch { return []; } }
function write(rows) { fs.writeFileSync(DB, JSON.stringify(rows, null, 2)); }
function auth(req, res, next) {
  if (!TOKEN || req.get('authorization') !== `Bearer ${TOKEN}`) return res.status(401).json({ error: 'unauthorized' });
  next();
}
function validUrl(raw) {
  try { const u = new URL(raw); return ['http:', 'https:'].includes(u.protocol) && !!u.hostname; } catch { return false; }
}
app.get('/health', (_req, res) => res.json({ ok: true, service: 'FM-DX Directory' }));
app.get('/api/servers', (_req, res) => res.json(read().filter(x => x.visibility === 'public').map(({ id, name, url, country, city, description, updatedAt }) => ({ id, name, url, country, city, description, updatedAt }))));
app.get('/api/servers/:id', (req, res) => {
  const item = read().find(x => x.id === req.params.id && x.visibility === 'public');
  if (!item) return res.status(404).json({ error: 'not_found' });
  res.json(item);
});
app.post('/api/servers', auth, (req, res) => {
  const { id, name, url, country = '', city = '', description = '', visibility = 'public' } = req.body || {};
  if (!name || !validUrl(url) || !['public', 'private'].includes(visibility)) return res.status(400).json({ error: 'invalid_server_data' });
  const rows = read(); const key = String(id || name.toLowerCase().replace(/[^a-z0-9]+/g, '-')).slice(0, 64);
  const entry = { id: key, name: String(name).slice(0, 80), url: String(url).slice(0, 300), country: String(country).slice(0, 60), city: String(city).slice(0, 60), description: String(description).slice(0, 240), visibility, updatedAt: new Date().toISOString() };
  const index = rows.findIndex(x => x.id === key); if (index >= 0) rows[index] = entry; else rows.push(entry);
  write(rows); res.status(201).json({ ok: true, id: key, visibility });
});
app.delete('/api/servers/:id', auth, (req, res) => { const rows = read(); const next = rows.filter(x => x.id !== req.params.id); write(next); res.json({ ok: true, removed: rows.length - next.length }); });
app.listen(PORT, '0.0.0.0', () => console.log(`FM-DX Directory listening on ${PORT}`));
